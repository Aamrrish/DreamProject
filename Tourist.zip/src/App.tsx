import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import HomePage from "./pages/HomePage";
import IPhone13ProMax2 from "./pages/IPhone13ProMax2";
import Main from "./pages/Main";
import IPhone13ProMax1 from "./pages/IPhone13ProMax1";
import Plan from "./pages/Plan";
import VisitHistoricPlaces from "./pages/VisitHistoricPlaces";
import DeleciousFood from "./pages/DeleciousFood";
import BuyPainting from "./pages/BuyPainting";
import BuyDoolls from "./pages/BuyDoolls";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    //TODO: Update meta titles and descriptions below
    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-pro-max-2":
        title = "";
        metaDescription = "";
        break;
      case "/main":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-pro-max-1":
        title = "";
        metaDescription = "";
        break;
      case "/plan":
        title = "";
        metaDescription = "";
        break;
      case "/visit-historic-places":
        title = "";
        metaDescription = "";
        break;
      case "/delecious-food":
        title = "";
        metaDescription = "";
        break;
      case "/buy-painting":
        title = "";
        metaDescription = "";
        break;
      case "/buy-doolls":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />

      <Route path="/iphone-13-pro-max-2" element={<IPhone13ProMax2 />} />

      <Route path="/main" element={<Main />} />

      <Route path="/iphone-13-pro-max-1" element={<IPhone13ProMax1 />} />

      <Route path="/plan" element={<Plan />} />

      <Route path="/visit-historic-places" element={<VisitHistoricPlaces />} />

      <Route path="/delecious-food" element={<DeleciousFood />} />

      <Route path="/buy-painting" element={<BuyPainting />} />

      <Route path="/buy-doolls" element={<BuyDoolls />} />
    </Routes>
  );
}
export default App;
