import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./BuyDoolls.css";

const BuyDoolls: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onAmazoninArtsAndHandicraftsLinkClick = useCallback(() => {
    window.open(
      " amazon.in/Arts-and-Handicrafts-Tanjore-Dancing-Doll/dp/B099PK74MC"
    );
  }, []);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="buy-doolls-div">
        <div className="frame-div6">
          <img
            className="fresh-folk-line-pattern3"
            alt=""
            src="../fresh-folk-line-pattern3@2x.png"
          />
          <div className="group-div16">
            <img className="images-3-13" alt="" src="../images-3-13@2x.png" />
            <div className="rectangle-div54" />
          </div>
          <div className="group-div17">
            <div className="thanjavur-doll-div">Thanjavur doll</div>
            <div className="rectangle-div55" />
          </div>
          <div className="the-thanjavur-doll-is-a-type-o">
            <p className="a-stall-in-thanjavur">
              <span>
                The Thanjavur doll is a type of traditional Indian bobblehead or
                roly-poly toy made of terracotta material. The centre of gravity
                and total weight of the doll is concentrated at its bottom-most
                point, generating a dance-like continuous movement with slow
                oscillations.[1] These toys are traditionally handmade, finished
                with detailed, painted exteriors. They have been recognized as a
                Geographical Indication by the Government of India as of
                2008-09.[2]
              </span>
            </p>
            <p className="a-stall-in-thanjavur">
              <span></span>
            </p>
            <p className="a-stall-in-thanjavur">
              <span></span>
            </p>
            <p className="a-stall-in-thanjavur">
              <span>A stall in Thanjavur</span>
            </p>
            <p className="a-stall-in-thanjavur">
              <span>&nbsp;</span>
            </p>
            <p className="a-stall-in-thanjavur">
              <span>{`Its Price is about `}</span>
              <span className="buy-this-from">{`$4Buy this from `}</span>
            </p>
          </div>
          <a
            className="amazoninarts-and-handicrafts"
            href=" amazon.in/Arts-and-Handicrafts-Tanjore-Dancing-Doll/dp/B099PK74MC"
            onClick={onAmazoninArtsAndHandicraftsLinkClick}
          >
            <p className="a-stall-in-thanjavur">&nbsp;</p>
            <p className="a-stall-in-thanjavur">
              amazon.in/Arts-and-Handicrafts-Tanjore-Dancing-Doll/dp/B099PK74MC
            </p>
            <p className="blank-line-p4">&nbsp;</p>
          </a>
        </div>
        <img className="vector-icon17" alt="" src="../vector7.svg" />
        <div className="rectangle-div56" />
        <div className="rectangle-div57" />
        <img
          className="arrow-left-icon6"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon7"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default BuyDoolls;
