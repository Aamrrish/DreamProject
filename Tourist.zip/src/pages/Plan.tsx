import { FunctionComponent, useState, useCallback } from "react";
import {
  FormControl,
  InputLabel,
  MenuItem,
  FormHelperText,
  Select,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./Plan.css";

const Plan: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onRectangleRectangle2Click = useCallback(() => {
    navigate("/main");
  }, [navigate]);

  const onGroupContainerClick = useCallback(() => {
    navigate("/main");
  }, [navigate]);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="plan-div1">
        <div className="rectangle-div37" />
        <div className="rectangle-div38" />
        <img
          className="dayflow-best-friends"
          alt=""
          src="../dayflow-best-friends@2x.png"
        />
        <FormControl
          className="group-formcontrol"
          sx={{ width: 250 }}
          variant="standard"
          required
        >
          <InputLabel color="secondary">location</InputLabel>
          <Select
            color="secondary"
            defaultValue="1"
            size="medium"
            label="location"
          >
            <MenuItem value="thanjavur">thanjavur</MenuItem>
            <MenuItem value="Chennai">Chennai</MenuItem>
            <MenuItem value="Ooty">Ooty</MenuItem>
          </Select>
          <FormHelperText />
        </FormControl>
        <div className="group-div9" onClick={onGroupContainerClick}>
          <div
            className="rectangle-div39"
            onClick={onRectangleRectangle2Click}
          />
          <div className="done-div1">done</div>
        </div>
        <img className="vector-icon13" alt="" src="../vector7.svg" />
        <div className="rectangle-div40" />
        <div className="rectangle-div41" />
        <img
          className="arrow-left-icon2"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon3"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default Plan;
