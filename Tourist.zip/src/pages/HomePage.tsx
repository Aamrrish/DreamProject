import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./HomePage.css";

const HomePage: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onGroupButtonClick = useCallback(() => {
    window.open("/plan");
  }, []);

  const onPlace3ButtonClick = useCallback(() => {
    window.open(
      "https://www.google.com/search?sxsrf=ALiCzsaXuj7fUuA1NJGAMpPnNCvu2RlnSQ:1662290519211&q=Park+in+thanjavur&npsic=0&rflfq=1&rldoc=1&rllag=10773568,79141903,1742&tbm=lcl&sxsrf=ALiCzsaXuj7fUuA1NJGAMpPnNCvu2RlnSQ:1662290519211&sa=X&ved=2ahUKEwjn1KTfgvv5AhVEVHwKHU_JBwoQtgN6BAgIEAE"
    );
  }, []);

  const onRes1ButtonClick = useCallback(() => {
    window.open(
      "https://www.google.com/search?q=Shraddha%20restaurant%20in%20thanjavur&oq=Sharadha+restaruant+in+thanjavur&aqs=chrome..69i57.13065j0j4&sourceid=chrome&ie=UTF-8&tbs=lf:1,lf_ui:9&tbm=lcl&sxsrf=ALiCzsZz7o-g42ZgZE5J3Vk1L2h7RsB-JQ:1662290655175&rflfq=1&num=10&rldimm=7822619799575830668&lqi=CiBTaHJhZGRoYSByZXN0YXVyYW50IGluIHRoYW5qYXZ1ckjh_L-o6oCAgAhaKhAAEAEYARgDIiBzaHJhZGRoYSByZXN0YXVyYW50IGluIHRoYW5qYXZ1cpIBF25vcnRoX2luZGlhbl9yZXN0YXVyYW50qgEbEAEqFyITc2hyYWRkaGEgcmVzdGF1cmFudCgA&phdesc=qXQtWhM-Y58&ved=2ahUKEwj6mI-gg_v5AhUECrcAHWnLD1MQvS56BAgEEAE&sa=X&rlst=f#rlfi=hd:;si:7822619799575830668,l,CiBTaHJhZGRoYSByZXN0YXVyYW50IGluIHRoYW5qYXZ1ckjh_L-o6oCAgAhaKhAAEAEYARgDIiBzaHJhZGRoYSByZXN0YXVyYW50IGluIHRoYW5qYXZ1cpIBF25vcnRoX2luZGlhbl9yZXN0YXVyYW50qgEbEAEqFyITc2hyYWRkaGEgcmVzdGF1cmFudCgA,y,qXQtWhM-Y58;mv:[[10.8359527,79.1491752],[10.731687899999999,79.1024631]];tbs:lrf:!1m4!1u3!2m2!3m1!1e1!1m4!1u5!2m2!5m1!1sgcid_3vegetarian_1restaurant!1m4!1u5!2m2!5m1!1sgcid_3north_1indian_1restaurant!1m4!1u2!2m2!2m1!1e1!2m1!1e2!2m1!1e5!2m1!1e3!3sIAEqAklO,lf:1,lf_ui:9"
    );
  }, []);

  const onRes2ButtonClick = useCallback(() => {
    window.open(
      "https://www.justdial.com/Thanjavur/Thevars-Biryani-Near-Maharaja-Readymade-Thanjavur-HO/9999P4362-4362-140604214301-Q7U2_BZDET"
    );
  }, []);

  const onRes3ButtonClick = useCallback(() => {
    window.open(
      "https://www.swiggy.com/restaurants/grand-dine-restaurant-new-housing-unit-thanjavur-city-thanjavur-201779"
    );
  }, []);

  const onPlace1ButtonClick = useCallback(() => {
    window.open("/visit-historic-places");
  }, []);

  const onPlace2ButtonClick = useCallback(() => {
    navigate("/buy-doolls");
  }, [navigate]);

  const onPlace3Button1Click = useCallback(() => {
    navigate("/buy-painting");
  }, [navigate]);

  const onUnsplashbAQH53VquTcImage2Click = useCallback(() => {
    navigate("/delecious-food");
  }, [navigate]);

  const onPlace4ButtonClick = useCallback(() => {
    navigate("/delecious-food");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="home-page-div">
        <img className="vector-icon" alt="" src="../vector@2x.png" />
        <img
          className="go-green-forest"
          alt=""
          src="../go-green-forest@2x.png"
        />
        <div className="hi-raja-div">Hi Raja!</div>
        <div className="welcome-for-a-new-trip">welcome for a new trip</div>
        <button className="group-button" onClick={onGroupButtonClick}>
          <div className="rectangle-div" />
          <div className="plan-div">Plan</div>
        </button>
        <div className="rectangle-div1">
          <div className="property-1default-div">
            <div className="rectangle-div2" />
          </div>
        </div>
        <div className="place-scroll-div">
          <div className="place-1-div">
            <img
              className="unsplashbaqh53vqutc-icon"
              alt=""
              src="../unsplashbaqh53vqutc@2x.png"
            />
            <div className="museum-div">Museum</div>
          </div>
          <div className="place-2-div">
            <div className="temple-div">Temple</div>
            <img
              className="unsplashwqungvubk9s-icon"
              alt=""
              src="../unsplashwqungvubk9s@2x.png"
            />
          </div>
          <button className="place-3-button" onClick={onPlace3ButtonClick}>
            <div className="park-div">Park</div>
            <img
              className="rectangle-icon"
              alt=""
              src="../rectangle-3@2x.png"
            />
          </button>
          <div className="group-div">
            <div className="property-1default-div1">
              <div className="rectangle-div3" />
              <img
                className="rectangle-icon1"
                alt=""
                src="../rectangle@2x.png"
              />
            </div>
            <div className="property-1variant3-div">
              <div className="rectangle-div4" />
              <img
                className="rectangle-icon2"
                alt=""
                src="../rectangle1@2x.png"
              />
            </div>
            <div className="property-1variant2-div">
              <div className="rectangle-div5" />
              <img
                className="rectangle-icon3"
                alt=""
                src="../rectangle2@2x.png"
              />
            </div>
          </div>
        </div>
        <div className="places-around-div">{`Places around `}</div>
        <div className="restur-scroll-div">
          <button className="res1-button" onClick={onRes1ButtonClick}>
            <div className="satharas-hotel-div">
              <p className="satharas-p">Satharas</p>
              <p className="hotel-p">Hotel</p>
            </div>
            <img className="icon" alt="" src="../20180419@2x.png" />
          </button>
          <button className="res2-button" onClick={onRes2ButtonClick}>
            <div className="thevars-hotel-div">
              <p className="satharas-p">Thevar’s</p>
              <p className="hotel-p">Hotel</p>
            </div>
            <img
              className="download-1-icon"
              alt=""
              src="../download-1@2x.png"
            />
          </button>
          <button className="res3-button" onClick={onRes3ButtonClick}>
            <div className="grand-dine-hotel">
              <p className="satharas-p">Grand Dine</p>
              <p className="hotel-p">Hotel</p>
            </div>
            <img className="download-icon" alt="" src="../download@2x.png" />
          </button>
          <div className="resturant-glass-div">
            <div className="property-1default-div1">
              <div className="rectangle-div6" />
              <img
                className="rectangle-icon4"
                alt=""
                src="../rectangle3@2x.png"
              />
            </div>
            <div className="property-1variant3-div1">
              <div className="rectangle-div4" />
              <img
                className="rectangle-icon5"
                alt=""
                src="../rectangle4@2x.png"
              />
            </div>
            <div className="property-1variant2-div1">
              <div className="rectangle-div8" />
              <img
                className="rectangle-icon6"
                alt=""
                src="../rectangle5@2x.png"
              />
            </div>
          </div>
        </div>
        <div className="restaurant-around-div">Restaurant around</div>
        <div className="frame-div">
          <button className="place-1-button" onClick={onPlace1ButtonClick}>
            <img
              className="unsplashbaqh53vqutc-icon"
              alt=""
              src="../unsplashbaqh53vqutc1@2x.png"
            />
            <div className="museum-div1">
              <p className="satharas-p">Visit historic</p>
              <p className="hotel-p">places</p>
            </div>
          </button>
          <button className="place-2-button" onClick={onPlace2ButtonClick}>
            <div className="temple-div1">Buy Dolls</div>
            <img
              className="unsplashwqungvubk9s-icon"
              alt=""
              src="../unsplashwqungvubk9s1@2x.png"
            />
          </button>
          <button className="place-3-button" onClick={onPlace3Button1Click}>
            <div className="park-div1">
              <p className="satharas-p">Buy</p>
              <p className="hotel-p">Paintings</p>
            </div>
            <img
              className="rectangle-icon"
              alt=""
              src="../rectangle-31@2x.png"
            />
          </button>
          <div className="group-div1">
            <div className="property-1default-div1">
              <div className="rectangle-div3" />
              <img
                className="rectangle-icon8"
                alt=""
                src="../rectangle6@2x.png"
              />
            </div>
            <div className="property-1variant3-div">
              <div className="rectangle-div4" />
              <img
                className="rectangle-icon9"
                alt=""
                src="../rectangle7@2x.png"
              />
            </div>
            <div className="property-1variant2-div">
              <div className="rectangle-div5" />
              <img
                className="rectangle-icon10"
                alt=""
                src="../rectangle8@2x.png"
              />
            </div>
          </div>
          <button className="place-4-button" onClick={onPlace4ButtonClick}>
            <img
              className="unsplashbaqh53vqutc-icon2"
              alt=""
              src="../rectangle3@2x.png"
              onClick={onUnsplashbAQH53VquTcImage2Click}
            />
            <div className="eat-delicious-foods">
              <p className="satharas-p">{`Eat Delicious `}</p>
              <p className="hotel-p">foods</p>
            </div>
          </button>
          <div className="group-div2">
            <div className="rectangle-div3" />
            <img
              className="rectangle-icon4"
              alt=""
              src="../rectangle3@2x.png"
            />
          </div>
        </div>
        <div className="things-you-can">Things you can</div>
        <div className="rectangle-div13" />
        <img
          className="mrdoublea-logo-1"
          alt=""
          src="../mrdoublea-logo-1@2x.png"
        />
        <img
          className="menu-icon"
          alt=""
          src="../menu.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default HomePage;
