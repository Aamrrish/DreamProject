import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./DeleciousFood.css";

const DeleciousFood: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="delecious-food-div">
        <div className="frame-div4">
          <img
            className="fresh-folk-line-pattern1"
            alt=""
            src="../fresh-folk-line-pattern@2x.png"
          />
          <div className="group-div12">
            <img className="images-3-11" alt="" src="../images-3-11@2x.png" />
            <div className="rectangle-div46" />
          </div>
          <div className="group-div13">
            <div className="delicious-foods-div">Delicious foods</div>
            <div className="rectangle-div47" />
          </div>
          <div className="if-a-traveller-having-food-at">
            <p className="if-a-traveller">
              If a traveller having food at Thanjavur doubts if Thanjavur has a
              sense of cultural elitism and aesthetics, it surely has come from
              the affluent Kaveri Delta near Thanjavur. In the grand scheme of
              things that get mentioned and appreciated such as music, dance,
              painting and art, Thanjavur cuisine gets sidelined, most of the
              time. However, if there is anything that deserves special mention,
              it is the Thanjavur cuisine.
            </p>
            <p className="if-a-traveller">&nbsp;</p>
            <p className="if-a-traveller">
              Thavala Adai is one of the best vegetarian dishes that one can
              find in Thanjavur. The chief ingredients of the item are lentils
              and rice. Traditionally cooked Thavala Adai offers a little
              crispness on the outside, while the inside of the Adai offers soft
              texture. It can be served with tomato gothsu or coconut chutney.
            </p>
            <p className="if-a-traveller"></p>
            <p className="if-a-traveller">
              Ashoka Halwa is another exceptional sweet that you can get in
              Thanjavur. The sweet is deeply tethered with several festivals
              such as wedding, christening and several other local festivals in
              Thanjavur.
            </p>
            <p className="if-a-traveller"></p>
            <p className="if-a-traveller">
              Paanagam is an exotic drink that you can devour as much as you
              like to quench your thirst. Because of the drink’s cooling
              effects, the best time to have the drink in the summer.
            </p>
            <p className="if-a-traveller"></p>
            <p className="if-a-traveller">
              Another drink to savour is Vasantha Neer that is made from mixing
              coconut water and mint. With a wide range of Dosas, Idlies and
              other Vada items, the long list of vegetarian food items goes on
              and on.
            </p>
            <p className="if-a-traveller">&nbsp;</p>
            <p className="if-a-traveller">
              Due to the presence of long coasts, a wide range of seafood items
              is available in Thanjavur. From fish to crab and exotic lobsters,
              Thanjavur will never disappoint anyone who loves non-vegetarian
              foods. The availability of numerous hotels and restaurants
              providing exceptional non-vegetarian food can make everyone
              wanting for more.
            </p>
            <p className="if-a-traveller"></p>
            <p className="if-a-traveller">
              There are also several sweet delicacies in Thanjavur such as Pal
              Payasam, Sooji Appam, Surul Poli and Kozhakottai that can leave
              everyone’s mouth watering for more.
            </p>
            <p className="if-a-traveller"></p>
            <p className="people-who-love">
              People who love tasting new cuisines and going on exciting
              gastronomical adventures, Thanjavur is a great place to be and
              experience the magical local food in all its exotic wonder and
              tastes
            </p>
          </div>
        </div>
        <img className="vector-icon15" alt="" src="../vector7.svg" />
        <div className="rectangle-div48" />
        <div className="rectangle-div49" />
        <img
          className="arrow-left-icon4"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon5"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default DeleciousFood;
