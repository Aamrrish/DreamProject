import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./Main.css";

const Main: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onHeartContainerClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='container3']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onHeartContainer1Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='container2']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onHeartContainer2Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='container1']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onHeartContainer3Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='container']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onHeartContainer4Click = useCallback(() => {
    navigate("/iphone-13-pro-max-2");
  }, [navigate]);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  const onGroupContainerClick = useCallback(() => {
    navigate("/iphone-13-pro-max-2");
  }, [navigate]);

  return (
    <>
      <div className="main-div">
        <div className="frame-div1">
          <div className="div">
            <div className="rectangle-div21" />
            <img
              className="rectangle-icon12"
              alt=""
              src="../rectangle-11@2x.png"
            />
            <div className="agathiyar-falls-div">Agathiyar falls</div>
            <div className="rectangle-div22" />
            <div className="heart-div" onClick={onHeartContainerClick}>
              <img className="vector-icon2" alt="" src="../vector-1.svg" />
              <button className="group-button1">
                <img className="vector-icon3" alt="" src="../vector2.svg" />
              </button>
            </div>
          </div>
          <div className="div1" data-scroll-to="container3">
            <div className="rectangle-div21" />
            <img
              className="rectangle-icon12"
              alt=""
              src="../rectangle-111@2x.png"
            />
            <div className="agathiyar-falls-div">Kolli Waterfall</div>
            <div className="rectangle-div22" />
            <div className="heart-div" onClick={onHeartContainer1Click}>
              <img className="vector-icon2" alt="" src="../vector-1.svg" />
              <button className="group-button1">
                <img className="vector-icon3" alt="" src="../vector2.svg" />
              </button>
            </div>
          </div>
          <div className="div2" data-scroll-to="container2">
            <div className="rectangle-div21" />
            <img
              className="rectangle-icon12"
              alt=""
              src="../rectangle-14@2x.png"
            />
            <div className="agathiyar-falls-div">Gov museum</div>
            <div className="rectangle-div22" />
            <div className="heart-div" onClick={onHeartContainer2Click}>
              <img className="vector-icon2" alt="" src="../vector-1.svg" />
              <button className="group-button1">
                <img className="vector-icon3" alt="" src="../vector4.svg" />
              </button>
            </div>
          </div>
          <div className="div3" data-scroll-to="container1">
            <div className="rectangle-div21" />
            <div className="agathiyar-falls-div"> Big Temple!</div>
            <div className="rectangle-div22" />
            <div className="heart-div" onClick={onHeartContainer3Click}>
              <img className="vector-icon2" alt="" src="../vector-1.svg" />
              <button className="group-button1">
                <img className="vector-icon3" alt="" src="../vector4.svg" />
              </button>
            </div>
            <img
              className="rectangle-icon12"
              alt=""
              src="../rectangle-17@2x.png"
            />
          </div>
          <div className="div4" data-scroll-to="container">
            <div className="rectangle-div21" />
            <img
              className="rectangle-icon12"
              alt=""
              src="../rectangle-20@2x.png"
            />
            <div className="agathiyar-falls-div">Rock cut cave</div>
            <div className="rectangle-div22" />
            <div className="heart-div" onClick={onHeartContainer4Click}>
              <img className="vector-icon2" alt="" src="../vector-1.svg" />
              <button className="group-button1">
                <img className="vector-icon3" alt="" src="../vector4.svg" />
              </button>
            </div>
          </div>
        </div>
        <img className="vector-icon12" alt="" src="../vector7.svg" />
        <div className="rectangle-div31" />
        <div className="rectangle-div32" />
        <img
          className="arrow-left-icon1"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon2"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
        <div className="group-div8" onClick={onGroupContainerClick}>
          <div className="rectangle-div33" />
          <div className="done-div">done</div>
        </div>
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default Main;
