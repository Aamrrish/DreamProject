import { FunctionComponent, useState, useCallback } from "react";
import { FormControlLabel, Checkbox } from "@mui/material";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./IPhone13ProMax2.css";

const IPhone13ProMax2: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onVectorIconClick = useCallback(() => {
    navigate("/main");
  }, [navigate]);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/main");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="iphone-13-pro-max-2">
        <img className="ellipse-icon" alt="" src="../ellipse-1.svg" />
        <div className="group-div3">
          <div className="rectangle-div14" />
          <div className="agasthiya-malai-div">Agasthiya Malai</div>
        </div>
        <FormControlLabel
          className="check-square-formcontrollabel"
          label=""
          labelPlacement="end"
          control={<Checkbox color="warning" defaultChecked size="2x" />}
        />
        <div className="group-div4">
          <div className="rectangle-div14" />
          <div className="agasthiya-malai-div">Kolli waterfall</div>
        </div>
        <div className="group-div5">
          <div className="rectangle-div14" />
          <div className="agasthiya-malai-div">Gov Museum</div>
        </div>
        <div className="group-div6">
          <div className="rectangle-div14" />
          <div className="agasthiya-malai-div">Big temple</div>
        </div>
        <div className="group-div7">
          <div className="rectangle-div14" />
          <div className="agasthiya-malai-div">Rock cut cave</div>
        </div>
        <FormControlLabel
          className="check-square-formcontrollabel1"
          label=""
          labelPlacement="end"
          control={<Checkbox color="warning" defaultChecked size="2x" />}
        />
        <FormControlLabel
          className="check-square-formcontrollabel2"
          label=""
          labelPlacement="end"
          control={<Checkbox color="warning" defaultChecked size="2x" />}
        />
        <FormControlLabel
          className="check-square-formcontrollabel3"
          label=""
          labelPlacement="end"
          control={<Checkbox color="warning" defaultChecked size="2x" />}
        />
        <FormControlLabel
          className="check-square-formcontrollabel4"
          label=""
          labelPlacement="end"
          control={<Checkbox color="warning" defaultChecked size="2x" />}
        />
        <img
          className="vector-icon1"
          alt=""
          src="../vector1.svg"
          onClick={onVectorIconClick}
        />
        <div className="rectangle-div19" />
        <div className="rectangle-div20" />
        <img
          className="arrow-left-icon"
          alt=""
          src="../arrowleft.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon1"
          alt=""
          src="../menu1.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default IPhone13ProMax2;
