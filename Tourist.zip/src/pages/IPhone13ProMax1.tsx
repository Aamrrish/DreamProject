import { FunctionComponent } from "react";
import "./IPhone13ProMax1.css";

const IPhone13ProMax1: FunctionComponent = () => {
  return (
    <div className="iphone-13-pro-max-1">
      <div className="frame-div2">
        <div className="rectangle-div34" />
        <div className="rectangle-div35" />
        <div className="rectangle-div36" />
        <div className="thanjavur-div">thanjavur</div>
        <div className="chennai-div">Chennai</div>
        <div className="ooty-div">Ooty</div>
      </div>
    </div>
  );
};

export default IPhone13ProMax1;
