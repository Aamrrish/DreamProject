import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./BuyPainting.css";

const BuyPainting: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="buy-painting-div">
        <div className="frame-div5">
          <img
            className="fresh-folk-line-pattern2"
            alt=""
            src="../fresh-folk-line-pattern@2x.png"
          />
          <div className="group-div14">
            <img className="images-3-12" alt="" src="../images-3-12@2x.png" />
            <div className="rectangle-div50" />
          </div>
          <div className="group-div15">
            <div className="thanjavur-painting-div">Thanjavur Painting</div>
            <div className="rectangle-div51" />
          </div>
          <div className="thanjavur-paintings-are-charac">
            Thanjavur paintings are characterised by rich and vivid colors,
            simple iconic composition, glittering gold foils overlaid on
            delicate but extensive gesso work and inlay of glass beads and
            pieces or very rarely precious and semi-precious gems. In Thanjavur
            paintings one can see the influence of Deccani, Vijayanagar, Maratha
            and even European or Company styles of painting. Essentially serving
            as devotional icons, the subjects of most paintings are Hindu gods,
            goddesses, and saints. Episodes from Hindu Puranas, Sthala-puranas
            and other religious texts were visualised, sketched or traced and
            painted with the main figure or figures placed in the central
            section of the picture (mostly within an architecturally delineated
            space such as a mantapa or prabhavali) surrounded by several
            subsidiary figures, themes and subjects. There are also many
            instances when Jain, Sikh, Muslim, other religious and even secular
            subjects were depicted in Tanjore paintings.
          </div>
        </div>
        <img className="vector-icon16" alt="" src="../vector7.svg" />
        <div className="rectangle-div52" />
        <div className="rectangle-div53" />
        <img
          className="arrow-left-icon5"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon6"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default BuyPainting;
