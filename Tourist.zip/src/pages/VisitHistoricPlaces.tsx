import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Hamburgur from "../components/Hamburgur";
import PortalPopup from "../components/PortalPopup";
import "./VisitHistoricPlaces.css";

const VisitHistoricPlaces: FunctionComponent = () => {
  const navigate = useNavigate();
  const [isHamburgurOpen, setHamburgurOpen] = useState(false);

  const onArrowLeftIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const openHamburgur = useCallback(() => {
    setHamburgurOpen(true);
  }, []);

  const closeHamburgur = useCallback(() => {
    setHamburgurOpen(false);
  }, []);

  return (
    <>
      <div className="visit-historic-places">
        <div className="frame-div3">
          <img
            className="fresh-folk-line-pattern"
            alt=""
            src="../fresh-folk-line-pattern@2x.png"
          />
          <div className="group-div10">
            <img className="images-3-1" alt="" src="../images-3-1@2x.png" />
            <div className="rectangle-div42" />
          </div>
          <div className="group-div11">
            <div className="kohanur-cave-div">{`Kohanur Cave `}</div>
            <div className="rectangle-div43" />
          </div>
          <div className="vallam-has-three-rock-cut-shri">
            Vallam has three rock-cut shrines belonging to Pallava era. Although
            these cave shrines have some of the best sculptures, they remain
            unknown to the public. All the three rock-cut shrines are excavated
            in a hillock. Even though it is not clearly known who built these
            cave shrines, it is clear that they were built during the period of
            Mahendravarma Pallava (580-630 CE).
          </div>
          <div className="this-is-the-uppermost-rock-of">
            <p className="this-is-the">
              This is the uppermost rock of the hill. One can reach this cave
              temple by climbing around 100+ steep steps. As this temple is
              still used for the purpose of worship, the entire cave is covered
              by iron grill from all the sides.
            </p>
            <p className="this-is-the"></p>
            <p className="this-is-the">
              This cave shrine is dedicated to Lord Shiva. Lord Shiva is named
              as Vedanteeswarar in this temple. The Goddess of the temple is
              Gnanambikai who is facing the eastern direction. Although Shiv
              Linga is placed in the small sanctum sanctorum, all other idols
              including Gnanambikai are found in the same shrine outside the
              sanctum sanctorum. The other idols that are found in the temple
              are Selva Vinayak (Ganesha), Muthukumaraswami along with his
              consorts Valli and Devasena, Dakshinamurthy, Chandikeswarar,
              Nagaraja and Bhuvaneswari. There is also a Nandi idol facing the
              main shrine. All these idols would have been installed at a later
              period and they do not belong to the period of this cave shrine.
            </p>
            <p className="this-is-the"></p>
            <p className="this-is-the"></p>
            <p className="this-is-the"></p>
            <p className="this-is-the">
              The highlight of this cave is two rock-cut relief images of
              Dwarapalaks standing on either side of the entrance of the main
              shrine.
            </p>
            <p className="this-is-the"></p>
            <p className="this-is-the"></p>
            <p className="this-is-the"></p>
            <p className="outside-to-this">
              Outside to this cave shrine, this is a big rock cut image of
              Ganesha is found. This image is very beautiful and displays some
              of the rare features. As the trunk of Ganesha (the elephant God)
              is turned towards right, he is called as 'Valampuri Vinayak'. He
              has four hands and seated in simhasana (royal throne). His one
              hand is resting on a small platform whereas his other arm is
              resting on his thigh. His upper arms carry a broken lotus stalk
              and another unclear material. The overall posture of Ganesha is
              rare and cannot be found anywhere
            </p>
          </div>
        </div>
        <img className="vector-icon14" alt="" src="../vector7.svg" />
        <div className="rectangle-div44" />
        <div className="rectangle-div45" />
        <img
          className="arrow-left-icon3"
          alt=""
          src="../arrowleft1.svg"
          onClick={onArrowLeftIconClick}
        />
        <img
          className="menu-icon4"
          alt=""
          src="../menu2.svg"
          onClick={openHamburgur}
        />
      </div>
      {isHamburgurOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeHamburgur}
        >
          <Hamburgur onClose={closeHamburgur} />
        </PortalPopup>
      )}
    </>
  );
};

export default VisitHistoricPlaces;
