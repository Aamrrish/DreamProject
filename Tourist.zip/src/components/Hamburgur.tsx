import { FunctionComponent } from "react";
import "./Hamburgur.css";

type HamburgurType = {
  onClose?: () => void;
};

const Hamburgur: FunctionComponent<HamburgurType> = ({ onClose }) => {
  return (
    <div className="hamburgur-div">
      <img
        className="mrdoublea-logo-11"
        alt=""
        src="../mrdoublea-logo-1@2x.png"
      />
      <div className="raja-div">Raja</div>
      <div className="group-div18">
        <div className="old-plan-div">Old Plan</div>
        <div className="rectangle-div58" />
      </div>
      <div className="group-div19">
        <div className="profile-div">Profile</div>
        <div className="rectangle-div59" />
      </div>
      <div className="group-div20">
        <div className="status-div">Status</div>
        <div className="rectangle-div58" />
      </div>
      <div className="group-div21">
        <div className="logout-div">Logout</div>
        <div className="rectangle-div58" />
      </div>
    </div>
  );
};

export default Hamburgur;
